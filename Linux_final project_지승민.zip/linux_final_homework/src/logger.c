#include "bank.h"

// 로그 파일을 가리키는 정적 파일 포인터 
static FILE* log_file = NULL;

// 로그 파일 초기화 (file_lock 뮤텍스 초기화 포함)
void init_logger() {
    // 1. 파일 뮤텍스 초기화
    #ifndef NO_MUTEX
    if (pthread_mutex_init(&file_lock, NULL) != 0) {
        perror("파일 락 뮤텍스 초기화 실패");
        exit(1);
    }
    #endif

    // 2. 로그 파일 열기 (쓰기 모드 - 기존 내용 덮어쓰기)
    log_file = fopen("transaction_log.txt", "w");
    if (log_file == NULL) {
        perror("transaction_log.txt 파일 열기 실패");
        exit(1);
    }
}

// 스레드 로그 기록 함수
void log_transaction(const char* message) {
    if (log_file == NULL) return;

    // 1. 현재 시간 획득 및 포맷팅
    time_t now;
    time(&now);
    struct tm *local_time = localtime(&now);
    char time_str[11]; // "[HH:MM:SS] "
    strftime(time_str, sizeof(time_str), "[%H:%M:%S]", local_time);

    // 2. 파일 접근을 위해 뮤텍스 잠금
    // NO_MUTEX가 정의되지 않았을 때만
    #ifndef NO_MUTEX
    pthread_mutex_lock(&file_lock);//락
    #endif

    
    fprintf(log_file, "%s %s\n", time_str, message);//파일 쓰기
    
    // 버퍼를 즉시 비워 파일에 쓰도록 보장
    fflush(log_file);
    //임계 구역 종료

    // 3. 뮤텍스 해제
    #ifndef NO_MUTEX
    pthread_mutex_unlock(&file_lock); //락 해제
    #endif
}

// 로거 종료 (파일 닫기 및 뮤텍스 파괴)
void close_logger() {
    if (log_file != NULL) {
        fclose(log_file);
        log_file = NULL;
    }

    #ifndef NO_MUTEX
    pthread_mutex_destroy(&file_lock);
    #endif
}