#include "bank.h"

// 계좌 및 관련 뮤텍스 초기화
void init_accounts() {
    for (int i = 0; i < NUM_ACCOUNTS; i++) {
        accounts[i].id = i;
        accounts[i].balance = INITIAL_BALANCE;
        
        #ifndef NO_MUTEX
        if (pthread_mutex_init(&accounts[i].mutex, NULL) != 0) {
            perror("계좌 뮤텍스 초기화 실패");
            exit(1);
        }
        #endif
    }
}

// 계좌 뮤텍스 파괴
void destroy_accounts() {
    for (int i = 0; i < NUM_ACCOUNTS; i++) {
        #ifndef NO_MUTEX
        pthread_mutex_destroy(&accounts[i].mutex);
        #endif
    }
}


// 입금 함수 
int deposit(int user_id, int account_id, double amount) {
    if (amount <= 0) return 0;

    #ifndef NO_MUTEX
    pthread_mutex_lock(&accounts[account_id].mutex); //락
    #endif

    accounts[account_id].balance += amount;
    double current_balance = accounts[account_id].balance;

    #ifndef NO_MUTEX
    pthread_mutex_unlock(&accounts[account_id].mutex); //락 해제
    #endif

    char log_buffer[256];
    sprintf(log_buffer, "사용자 %d: 계좌 %d에 %.2f원 입금 (현재 잔액: %.2f원)", 
            user_id, account_id, amount, current_balance);
    log_transaction(log_buffer);
    return 1;
}

//출금 함수
int withdraw(int user_id, int account_id, double amount) {
    if (amount <= 0) return 0;

    int success = 0;
    double current_balance;

    #ifndef NO_MUTEX
    pthread_mutex_lock(&accounts[account_id].mutex); //락
    #endif

    if (accounts[account_id].balance >= amount) { //음수 잔액 방지
        accounts[account_id].balance -= amount;   
        current_balance = accounts[account_id].balance;
        success = 1;
    } else {
        current_balance = accounts[account_id].balance;
        success = 0;
    }

    #ifndef NO_MUTEX
    pthread_mutex_unlock(&accounts[account_id].mutex); //락 해제
    #endif

    char log_buffer[256];
    if (success) {
        sprintf(log_buffer, "사용자 %d: 계좌 %d에서 %.2f원 출금 (현재 잔액: %.2f원)", 
                user_id, account_id, amount, current_balance);
    } else {
        sprintf(log_buffer, "사용자 %d: 계좌 %d에서 %.2f원 출금 시도 (거래 실패: 잔액 부족. 잔액: %.2f원)", 
                user_id, account_id, amount, current_balance);
    }
    log_transaction(log_buffer);
    return success;
}


// 계좌 이체 함수 
static int internal_withdraw(int account_id, double amount) {
    if (accounts[account_id].balance >= amount) {
        accounts[account_id].balance -= amount; //값 반영
        return 1;
    }
    return 0;
}
static void internal_deposit(int account_id, double amount) {
    accounts[account_id].balance += amount; //값 반영
}

// 계좌 이체 메인 함수
int transfer(int user_id, int from_account, int to_account, double amount) {
    if (from_account == to_account) return 0;
    if (amount <= 0) return 0;

    // 데드락 방지 (항상 ID가 낮은 락을 먼저 잡음)
    int lock1_id = (from_account < to_account) ? from_account : to_account;
    int lock2_id = (from_account < to_account) ? to_account : from_account;

    int success = 0;
    char log_buffer[256];

    #ifndef NO_MUTEX
    pthread_mutex_lock(&accounts[lock1_id].mutex);
    pthread_mutex_lock(&accounts[lock2_id].mutex);
    #endif

    if (internal_withdraw(from_account, amount)) {
        internal_deposit(to_account, amount);
        success = 1;
    } else {
        success = 0;
    }

    double from_balance = accounts[from_account].balance;
    double to_balance = accounts[to_account].balance;

    #ifndef NO_MUTEX
    pthread_mutex_unlock(&accounts[lock2_id].mutex);//획득한 순서의 역순으로 해제
    pthread_mutex_unlock(&accounts[lock1_id].mutex);
    #endif

    if (success) {
        sprintf(log_buffer, "사용자 %d: 계좌 %d -> 계좌 %d로 %.2f원 이체 (잔액: %d:%.2f, %d:%.2f)",
                user_id, from_account, to_account, amount,
                from_account, from_balance, to_account, to_balance);
    } else {
        sprintf(log_buffer, "사용자 %d: 계좌 %d -> 계좌 %d 이체 실패 (%.2f원 시도. 잔액 부족. 잔액: %.2f)",
                user_id, from_account, to_account, amount, accounts[from_account].balance);
    }
    log_transaction(log_buffer);

    return success; // 이체 성공 여부 반환 
}


// 모든 계좌의 총 잔액을 계산하는 함수
double get_total_balance_safely() {
    double total_balance = 0;

    #ifndef NO_MUTEX//if not defined(safe 버전에는 no_mutex가 정의가 안되어있으니(true) 실행됨)
    for (int i = 0; i < NUM_ACCOUNTS; i++) {
        pthread_mutex_lock(&accounts[i].mutex);
    }
    #endif

    for (int i = 0; i < NUM_ACCOUNTS; i++) {
        total_balance += accounts[i].balance;
    }

    #ifndef NO_MUTEX
    for (int i = 0; i < NUM_ACCOUNTS; i++) {
        pthread_mutex_unlock(&accounts[i].mutex);
    }
    #endif

    return total_balance;
}