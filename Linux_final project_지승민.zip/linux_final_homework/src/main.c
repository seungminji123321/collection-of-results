#include "bank.h"

Account accounts[NUM_ACCOUNTS]; //계좌
pthread_mutex_t file_lock; //필수조건: 파일 접근 시 동시성 문제를 피하기 위해 별도의 file_lock 뮤텍스
volatile int simulation_running = 1; // 1: 실행 중, 0: 종료

int main() {
    pthread_t user_threads[NUM_USERS];
    pthread_t monitor_thread;
    ThreadArgs user_args[NUM_USERS];
    
    struct timeval start_time, end_time;
    double elapsed_time;

    // 랜덤 시드 초기화
    srand(time(NULL));

    // 로거 및 계좌 초기화
    init_logger();
    init_accounts();

    log_transaction("시뮬레이션 시작. 로거 및 계좌 초기화 완료.");

    // 초기 총 잔액 계산 및 출력
    double initial_total_balance = get_total_balance_safely();
    printf("[MAIN] 초기 총 잔액: %.2f\n", initial_total_balance);
    
    char log_buf[100];
    sprintf(log_buf, "초기 총 잔액: %.2f", initial_total_balance); //log_buf안에 "초기 총 잔액 넣기 
    log_transaction(log_buf); //txt 파일에 쓰기


    //모니터 스레드 생성
    if (pthread_create(&monitor_thread, NULL, monitor_thread_func, NULL) != 0) {
        perror("모니터 스레드 생성 실패");
        return 1;
    }



    gettimeofday(&start_time, NULL); //시간 측정 시작

    //사용자 스레드 생성
    for (int i = 0; i < NUM_USERS; i++) {
        user_args[i].user_id = i + 1; // 사용자 ID는 1부터 시작
        if (pthread_create(&user_threads[i], NULL, user_thread_func, &user_args[i]) != 0) {
            perror("사용자 스레드 생성 실패");
            return 1;
        }
    }

    printf("[MAIN] %d개의 사용자 스레드 및 모니터 스레드 생성 완료.\n", NUM_USERS);

    
    //스레드 반환값 처리
    double total_net_change = 0.0; // 10개 스레드의 총 입/출금액 합계

    // 사용자 스레드 종료 대기 Join 및 반환값 수신
    for (int i = 0; i < NUM_USERS; i++) {
        void* return_value = NULL;
        pthread_join(user_threads[i], &return_value); // 스레드 종료 및 반환값 받기
        
        if (return_value) {
            // 스레드가 반환한 net_change 포인터를 double로 변환
            double* net_change_ptr = (double*)return_value;
            total_net_change += *net_change_ptr; // 합계에 더하기
            free(net_change_ptr); // malloc으로 할당했으므로 free
        }
    }

    //시간 측정 종료
    gettimeofday(&end_time, NULL);
    elapsed_time = (end_time.tv_sec - start_time.tv_sec) + 
                   (end_time.tv_usec - start_time.tv_usec) / 1000000.0;
    
    printf("[MAIN] 모든 사용자 스레드 작업 완료. (소요 시간: %.6f 초)\n", elapsed_time);


    // 모니터 스레드 종료 신호 및 대기
    simulation_running = 0; 
    pthread_join(monitor_thread, NULL);
    printf("[MAIN] 모니터 스레드 종료 완료.\n");

    //최종 결과 확인
    // 예상 잔액 = 초기 잔액 + 10개 스레드의 총 순수 입/출금액
    double expected_total_balance = initial_total_balance + total_net_change; // 출입금 기록을 바탕으로 예상값
    double final_total_balance = get_total_balance_safely(); //실제 계좌에 있는 금액
    
    printf("\n[MAIN] 최종 총 잔액 (계산됨): %.2f\n", final_total_balance);
    printf("[MAIN] 예상 총 잔액 (기대값): %.2f\n", expected_total_balance);

    sprintf(log_buf, "최종 총 잔액: %.2f (기대값: %.2f)", final_total_balance, expected_total_balance);
    log_transaction(log_buf);

    // 데이터 일관성 검증
    if (final_total_balance == expected_total_balance) {
        printf("[MAIN] 결과: 데이터 일관성 유지 성공!\n");
        log_transaction("결과: 데이터 일관성 유지 성공!");
    } else {
        printf("[MAIN] 결과: 데이터 일관성 실패!!! (경쟁 조건 발생)\n");
        log_transaction("결과: 데이터 일관성 실패!!!");
    }

    printf("[MAIN] 스레드 작업 소요 시간: %.6f 초\n", elapsed_time);
    
    sprintf(log_buf, "스레드 작업 소요 시간: %.6f 초", elapsed_time);
    log_transaction(log_buf);
    log_transaction("시뮬레이션 종료.");

    //자원 해제
    destroy_accounts();
    close_logger();

    return 0;
}