#include "bank.h"

// 사용자 스레드 (입금/출금/이체 랜덤 수행)
void* user_thread_func(void* arg) {
    ThreadArgs* args = (ThreadArgs*)arg;
    int user_id = args->user_id;

    unsigned int seed = (unsigned int)(time(NULL) ^ (user_id << 8));
    
    // 이 스레드가 발생시킨 은행 전체 시스템의 총 잔액 
    double net_change = 0.0;

    // 3-way 랜덤
    // 각 스레드가 2000번의 랜덤 거래를 수행
    for (int i = 0; i < TRANSACTIONS_PER_USER; i++) {
        
        // 1. (100원~500원) 랜덤 금액 생성
        int amount_in_hundreds = (rand_r(&seed) % (int)(MAX_TRANSACTION_AMOUNT / 100.0)) + 1;
        double amount = (double)(amount_in_hundreds * 100.0);

        // 2. 0:입금, 1:출금, 2:이체 중 랜덤으로 하나 선택
        int action = rand_r(&seed) % 3;

        // (계좌는 5개 (0~4) 중에서 랜덤 선택)
        int account_id, from_account, to_account;

        switch (action) {
            case 0: // 입금
                account_id = rand_r(&seed) % NUM_ACCOUNTS;
                deposit(user_id, account_id, amount);
                // 입금은 총 잔액을 증가시키므로 net_change에 더함
                net_change += amount;
                break;

            case 1: // 출금
                account_id = rand_r(&seed) % NUM_ACCOUNTS;
                // 출금이 성공했을 때만 net_change에서 뺌
                if (withdraw(user_id, account_id, amount) == 1) {
                    net_change -= amount;
                }
                break;

            case 2: // 계좌 이체
                from_account = rand_r(&seed) % NUM_ACCOUNTS;
                to_account = rand_r(&seed) % NUM_ACCOUNTS;
                while (from_account == to_account) { // 동일 계좌 방지
                    to_account = rand_r(&seed) % NUM_ACCOUNTS;
                }
                transfer(user_id, from_account, to_account, amount);
                //이체는 시스템 총 잔액을 바꾸지 않으므로 net_change는 0
                //if 문 필요 없음
                break;
        }
        
        usleep((rand_r(&seed) % 1000) + 100);
    }
    


    //스레드 종료 시 net_change 반환 준비
    double* return_value = malloc(sizeof(double));
    if (return_value) {
        *return_value = net_change;
    }

    return (void*)return_value; // 계산된 net_change 포인터 반환
}

// 모니터 스레드 (총 잔액 주기적 확인)
void* monitor_thread_func(void* arg) {
    
    while (simulation_running) {
        
        double total_balance = get_total_balance_safely();
        printf("[MONITOR] 현재 모든 계좌의 총 잔액: %.2f\n", total_balance);

        if (!simulation_running) {
            break;
        }
        
        usleep(100000); // 0.1초 대기
    }

    printf("[MONITOR] 모니터 스레드 종료.\n");
    return NULL;
}