#ifndef BANK_H
#define BANK_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>     
#include <time.h>
#include <string.h>
#include <sys/time.h> //gettimeofday

// ===시뮬레이션 설정===
#define NUM_ACCOUNTS 5 //은행계좌(필수:5개 이상의)
#define NUM_USERS 10  //사용자 스레드(필수:10개 이상의)
#define INITIAL_BALANCE 1000// 초기잔액
#define MAX_TRANSACTION_AMOUNT 500 // 한 번에 처리할 수 있는 최대 거래 금액
#define TRANSACTIONS_PER_USER 2000   // 각 스레드가 2000번의 랜덤 거래를 수행

// ===계좌 구조체===
typedef struct {
    int id;
    double balance;
    pthread_mutex_t mutex;
} Account;

// ===스레드 인자 구조체===
typedef struct {
    int user_id;
} ThreadArgs;

// ===전역 변수 선언===
extern Account accounts[NUM_ACCOUNTS];
extern pthread_mutex_t file_lock;
extern volatile int simulation_running;


// ===함수 프로토타입===

//account.c
void init_accounts();
void destroy_accounts();
int deposit(int user_id, int account_id, double amount); //  입금
int withdraw(int user_id, int account_id, double amount); // 출금
double get_total_balance_safely();// 모든 계좌의 총 잔액을 계산하는 함수
int transfer(int user_id, int from_account, int to_account, double amount); //이체



//logger.c
void init_logger();
void log_transaction(const char* message);
void close_logger();

//thread_manager.c
void* user_thread_func(void* arg);
void* monitor_thread_func(void* arg);


#endif // BANK_H