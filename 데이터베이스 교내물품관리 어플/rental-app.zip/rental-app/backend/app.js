require('dotenv').config();
const express    = require('express');
const mysql      = require('mysql2/promise');
const cors       = require('cors');
const bodyParser = require('body-parser');
const path       = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// MySQL 연결 풀
const pool = mysql.createPool({
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

// 1) 학생 목록
app.get('/api/students', async (_, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT student_id, student_name FROM student'
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 2) 물품 목록
app.get('/api/items', async (_, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT product_id, product_name FROM rental_item'
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 3) 대여 처리: is_returned 없이 새 레코드 삽입
app.post('/api/rent', async (req, res) => {
  try {
    const { student_id, product_id } = req.body;
    const today = new Date();
    const yyyy  = today.getFullYear();
    const mm    = String(today.getMonth() + 1).padStart(2, '0');
    const dd    = String(today.getDate()).padStart(2, '0');
    const rental_date = `${yyyy}-${mm}-${dd}`;

    const due = new Date(today);
    due.setDate(due.getDate() + 7);
    const yyyy2 = due.getFullYear();
    const mm2   = String(due.getMonth() + 1).padStart(2, '0');
    const dd2   = String(due.getDate()).padStart(2, '0');
    const due_date = `${yyyy2}-${mm2}-${dd2}`;

    await pool.query(
      `INSERT INTO period
         (student_id, product_id, rental_date, due_date, days_overdue, is_returned)
       VALUES (?, ?, ?, ?, 0, 0)`,
      [student_id, product_id, rental_date, due_date]
    );

    res.json({ success: true, rental_date, due_date });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 4) 반납 처리: is_returned = 1, days_overdue 업데이트
app.post('/api/return', async (req, res) => {
  try {
    const { student_id, product_id } = req.body;
    // 가장 최근 미반납 레코드 찾기
    const [rows] = await pool.query(
      `SELECT id, due_date
       FROM period
       WHERE student_id = ? AND product_id = ? AND is_returned = 0
       ORDER BY id DESC
       LIMIT 1`,
      [student_id, product_id]
    );
    if (rows.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: '반납할 대여 기록이 없습니다.' });
    }
    const recordId = rows[0].id;
    // days_overdue 계산 후 업데이트
    await pool.query(
      `UPDATE period
         SET days_overdue = GREATEST(DATEDIFF(CURDATE(), due_date), 0),
             is_returned = 1
       WHERE id = ?`,
      [recordId]
    );
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// 5) 대여 내역 조회: 미반납(active) 레코드만
app.get('/api/history/:student_id', async (req, res) => {
  try {
    const sid = req.params.student_id;
    const [rows] = await pool.query(
      `SELECT
         r.product_name,
         DATE_FORMAT(p.rental_date, '%Y-%m-%d') AS rental_date,
         DATE_FORMAT(p.due_date,   '%Y-%m-%d') AS due_date,
         p.days_overdue
       FROM period p
       JOIN rental_item r ON p.product_id = r.product_id
       WHERE p.student_id = ? AND p.is_returned = 0
       ORDER BY p.id DESC`,
      [sid]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 서버 기동
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
