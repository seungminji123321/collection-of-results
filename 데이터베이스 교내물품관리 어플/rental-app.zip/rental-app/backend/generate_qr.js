require('dotenv').config();
const mysql  = require('mysql2/promise');
const QRCode = require('qrcode');
const fs     = require('fs');
const path   = require('path');

async function main() {
  const pool = mysql.createPool({
    host:     process.env.DB_HOST,
    user:     process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10
  });

  const outBase = path.join(__dirname, '../frontend/qrcodes');
  const studentDir = path.join(outBase, 'students');
  const itemDir    = path.join(outBase, 'items');

  fs.mkdirSync(studentDir, { recursive: true });
  fs.mkdirSync(itemDir,    { recursive: true });

  // 학생 QR
  const [students] = await pool.query('SELECT student_id FROM student');
  for (const { student_id } of students) {
    const data = JSON.stringify({ type: 'student', id: student_id });
    await QRCode.toFile(
      path.join(studentDir, `${student_id}.png`),
      data,
      { width: 256 }
    );
  }

  // 물품 QR
  const [items] = await pool.query('SELECT product_id FROM rental_item');
  for (const { product_id } of items) {
    const data = JSON.stringify({ type: 'item', id: product_id });
    await QRCode.toFile(
      path.join(itemDir, `${product_id}.png`),
      data,
      { width: 256 }
    );
  }

  console.log('✅ QR 코드 생성 완료');
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
